﻿船舶设备检修助手 — 打开说明
================================

直接双击 index.html 会白屏（浏览器禁止 file:// 加载模块）。
请用以下任一方式打开：

【方式1】简易服务器（推荐）
  解压后进入 dist 目录，执行：
    python -m http.server 8080
  浏览器访问 http://localhost:8080

【方式2】VS Code
  装 Live Server 插件 → 右键 index.html → Open with Live Server

【方式3】部署到服务器
  将 dist 目录上传到任意 Web 服务器（Nginx / Apache / 对象存储等）
